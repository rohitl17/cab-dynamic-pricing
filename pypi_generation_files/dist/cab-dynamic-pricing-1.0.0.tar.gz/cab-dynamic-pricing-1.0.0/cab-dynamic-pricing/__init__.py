# __init__.py

# Version of the cab-dynamic-pricing package
__version__ = "1.0.0"
